﻿namespace _01.Harvesting_Fields
{
    public enum AccessModifier
    {
        Private,
        Protected,
        Public
    }
}