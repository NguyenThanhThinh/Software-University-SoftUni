﻿namespace _03BarracksFactory.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}