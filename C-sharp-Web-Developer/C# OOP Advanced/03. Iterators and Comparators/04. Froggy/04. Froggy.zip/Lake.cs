﻿using System.Collections;
using System.Collections.Generic;

namespace _04.Froggy
{
    public class Lake : IEnumerable<int>
    {
        private List<int> data;

        public Lake(List<int> data)
        {
            this.Data = data;
        }

        public List<int> Data
        {
            get { return data; }
            set { data = value; }
        }

        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 0; i < this.Data.Count; i += 2)
            {
                yield return this.Data[i];
            }

            int nextIndex = this.Data.Count % 2 == 0 ? this.Data.Count - 1 : this.Data.Count - 2;

            for (int i = nextIndex; i >= 0; i -= 2)
            {
                yield return this.Data[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}