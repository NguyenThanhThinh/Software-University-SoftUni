﻿[Softuni("Ventsi")]
public class Startup
{
    [Softuni("Gosho")]
    public static void Main()
    {
        //var tracker = new Tracker();
        //tracker.PrintMethodsByAuthor();
    }
}