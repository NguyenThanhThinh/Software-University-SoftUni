﻿public enum CoffeePrice
{
    Small = 50,
    Normal = 100,
    Double = 200
}