﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09.CustomListSorter
{
    public class Sorter<T> : IComparable<T> where T : IComparable<T>
    {
        public static void Sort()
        {
            
        }

        public int CompareTo(T other)
        {
            throw new NotImplementedException();
        }
    }
}
