﻿namespace _05.BorderControl
{
    public interface ICountable
    {
        string Id { get; set; }
    }
}