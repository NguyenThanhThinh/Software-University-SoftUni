﻿namespace _09.CollectionHierarchy
{
    public interface IMyList : IAddableRemovableCollection
    {
        int Used { get; }
    }
}