﻿namespace _03.Ferrari
{
    public interface ICar
    {
        string PushBrakes();
        string PushGaz();
    }
}