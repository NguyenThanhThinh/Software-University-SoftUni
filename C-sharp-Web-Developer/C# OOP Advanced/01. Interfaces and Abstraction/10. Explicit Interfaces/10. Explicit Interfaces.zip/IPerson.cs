﻿namespace _10.Explicit_Interfaces
{
    public interface IPerson
    {
        string Name { get; set; }
        int Age { get; set; }
        void GetName();
    }
}