﻿namespace _05.BorderControl
{
    public interface ICountable
    {
        string Id { get; set; }

        void FakeID(string fakeID);
    }
}