﻿public class NightVision : Ammunition
{
    private const double WeightConst = 0.8d;

    public NightVision(string name)
        : base(name, WeightConst)
    {
    }
}