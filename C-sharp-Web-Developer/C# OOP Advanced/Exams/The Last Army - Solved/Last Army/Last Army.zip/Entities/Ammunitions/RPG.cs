﻿public class RPG : Ammunition
{
    private const double WeightConst = 17.1d;

    public RPG(string name)
        : base(name, WeightConst)
    {
    }
}