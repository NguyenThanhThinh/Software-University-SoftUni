﻿public class AutomaticMachine : Ammunition
{
    private const double WeightConst = 6.3;

    public AutomaticMachine(string name)
        : base(name, WeightConst)
    {
    }
}