﻿namespace _09.Traffic_Lights
{
    public enum Lights
    {
       Red,
       Green,
       Yellow
    }
}