﻿namespace _01.Card_Suit
{
    public enum Cards
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    } 
}