﻿namespace _01.Card_Suit
{
    public enum Suit
    {
        Clubs,
        Hearts,
        Diamonds,
        Spades
    } 
}