﻿namespace _10.Inferno_Infinity
{
    public class Amethyst : Gem
    {
        public Amethyst(string quality) 
            : base(2, 8, 4, quality)
        {
        }
    }
}