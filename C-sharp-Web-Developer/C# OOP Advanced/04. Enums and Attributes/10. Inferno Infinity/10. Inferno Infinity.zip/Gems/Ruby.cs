﻿namespace _10.Inferno_Infinity
{
    public class Ruby : Gem
    {
        public Ruby(string quality) 
            : base(7, 2, 5, quality)
        {
        }
    }
}