﻿namespace _10.Inferno_Infinity
{
    public class Emerald : Gem
    {
        public Emerald(string quality) 
            : base(1, 4, 9, quality)
        {
        }
    }
}