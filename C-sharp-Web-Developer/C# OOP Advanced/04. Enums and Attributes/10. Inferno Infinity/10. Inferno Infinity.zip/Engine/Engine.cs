﻿using _10.Inferno_Infinity.IO;
using _10.Inferno_Infinity.Factory;

namespace _10.Inferno_Infinity.Engine
{
    public class Engine
    {
        public void Start()
        {
            string input = ReadLine.Read();

            while (!input.Equals("END"))
            {
                ProcessTheCommand(input);
                input = ReadLine.Read();
            }
        }

        //Refactor this to a separate class Command???
        private void ProcessTheCommand(string input)
        {
            var inputSplit = input.Split(';');
            string command = inputSplit[0];
            string name = inputSplit[1];
            int index = 0;

            switch (command)
            {
                case "Create":
                    Repository.Repository.AddWeapon(WeaponFactory.CreateWeapon(input));
                    break;
                case "Add":
                    index = int.Parse(inputSplit[2]);
                    string gem = inputSplit[3];
                    Repository.Repository.Weapons[name].AddGemInSocket(index, GemFactory.CreateGem(gem));
                    break;
                case "Remove":
                    index = int.Parse(inputSplit[2]);
                    Repository.Repository.Weapons[name].RemoveGemFromSocket(index);
                    break;
                case "Print":
                    WriteLine.Write(Repository.Repository.Weapons[name].ToString());
                    break;
            }
        }
    }
}