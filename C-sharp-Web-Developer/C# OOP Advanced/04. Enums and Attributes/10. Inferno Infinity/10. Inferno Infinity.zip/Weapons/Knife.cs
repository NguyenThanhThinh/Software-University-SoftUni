﻿namespace _10.Inferno_Infinity
{
    public class Knife : Weapon
    {
        public Knife(string name, string rarity) 
            : base(name, rarity, 3, 4, 2)
        {
        }
    }
}