﻿namespace _10.Inferno_Infinity
{
    public class Sword : Weapon
    {
        public Sword(string name, string rarity) 
            : base(name, rarity, 4, 6, 3)
        {
        }
    }
}