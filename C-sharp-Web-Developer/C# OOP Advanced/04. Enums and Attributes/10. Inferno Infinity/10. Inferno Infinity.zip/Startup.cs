﻿using _10.Inferno_Infinity.Engine;

namespace _10.Inferno_Infinity
{
    public class Startup
    {
        public static void Main()
        {
            Engine.Engine engine = new Engine.Engine();
            engine.Start();
        }
    }
}