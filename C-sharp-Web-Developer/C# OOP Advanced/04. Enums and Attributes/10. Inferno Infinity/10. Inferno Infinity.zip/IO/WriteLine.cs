﻿using System;

namespace _10.Inferno_Infinity.IO
{
    public static class WriteLine
    {
        public static void Write(string text)
        {
            Console.WriteLine(text);
        }
    }
}