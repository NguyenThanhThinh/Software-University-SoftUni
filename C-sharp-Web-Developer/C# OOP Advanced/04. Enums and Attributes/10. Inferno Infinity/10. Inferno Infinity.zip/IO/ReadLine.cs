﻿using System;

namespace _10.Inferno_Infinity.IO
{
    public static class ReadLine
    {
        public static string Read()
        {
            return Console.ReadLine();
        }
    }
}