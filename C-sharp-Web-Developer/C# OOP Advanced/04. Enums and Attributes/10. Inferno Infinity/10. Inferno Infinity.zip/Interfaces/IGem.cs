﻿namespace _10.Inferno_Infinity
{
    public interface IGem
    {
        int Strength { get; }
        int Agility { get; }
        int Vitality { get; }
        string Quality { get; }
        //void IncreaseStats(string quality);
    }
}