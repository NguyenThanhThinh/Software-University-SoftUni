﻿namespace _08.Card_Game
{
    public class SecondPlayer : Player
    {
        public SecondPlayer(string name) 
            : base(name)
        {
        }
    }
}