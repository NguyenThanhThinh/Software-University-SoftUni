﻿namespace _08.Card_Game
{
    public class FirstPlayer : Player
    {
        public FirstPlayer(string name) 
            : base(name)
        {
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}