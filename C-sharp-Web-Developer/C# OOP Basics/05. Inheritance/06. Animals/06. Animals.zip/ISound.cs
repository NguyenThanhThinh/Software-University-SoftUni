﻿public interface ISound
{
    string GetAnimalSound();
}