﻿public class OtherFood : Food
{
    private const int OtherFoodHappiness = -1;

    public OtherFood()
        : base(OtherFoodHappiness)
    {
    }
}