﻿public class Cram : Food
{
    private const int CramHappiness = 2;

    public Cram()
        : base(CramHappiness)
    {
    }
}