﻿public interface IMood
{
    int Mood { get; set; }
}