﻿public class Lembas : Food
{
    private const int LembasHappiness = 3;

    public Lembas()
        : base(LembasHappiness)
    {
    }
}