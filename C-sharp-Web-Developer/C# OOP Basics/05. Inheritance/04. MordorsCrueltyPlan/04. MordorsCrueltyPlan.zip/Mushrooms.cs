﻿public class Mushrooms : Food
{
    private const int MushroomsHappiness = -10;

    public Mushrooms()
        : base(MushroomsHappiness)
    {
    }
}