﻿public class HoneyCake : Food
{
    private const int HoneyCakeHappiness = 5;

    public HoneyCake()
        : base(HoneyCakeHappiness)
    {
    }
}