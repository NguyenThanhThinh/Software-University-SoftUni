﻿public class Melon : Food
{
    private const int MelonHappiness = 1;

    public Melon()
        : base(MelonHappiness)
    {
    }
}