﻿public interface IFood
{
    int Happiness { get; }
}