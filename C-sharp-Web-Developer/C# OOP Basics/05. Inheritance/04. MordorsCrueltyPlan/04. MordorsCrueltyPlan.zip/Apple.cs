﻿public class Apple : Food
{
    private const int AppleHappiness = 1;

    public Apple()
        : base(AppleHappiness)
    {
    }
}