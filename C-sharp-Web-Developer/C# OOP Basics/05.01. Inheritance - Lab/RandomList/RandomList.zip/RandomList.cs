﻿using System;
using System.Collections;

public class RandomList : ArrayList
{
    private Random rand;

    public RandomList()
    {
        this.rand = new Random();
    }

    public string RandomString()
    {
        return "";
    }
}

