﻿public abstract class Felime : Mammal
{
    protected Felime(string name, double weight, string type, string livingRegion) 
        : base(name, weight, type, livingRegion)
    {
    }
}