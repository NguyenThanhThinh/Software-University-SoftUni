﻿using System;
using System.Collections.Generic;

public class Tires
{
    public Dictionary<double, int> tire;

    public Tires(/*int age, double pressure*/)
    {
        this.tire = new Dictionary<double, int>();
        //this.tire[age] = pressure;
    }
}