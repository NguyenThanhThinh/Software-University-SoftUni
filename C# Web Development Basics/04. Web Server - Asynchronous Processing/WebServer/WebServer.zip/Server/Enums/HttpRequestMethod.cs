﻿namespace WebServer.Server.Enums
{
    public enum HttpRequestMethod
    {
        POST,
        GET
    }
}