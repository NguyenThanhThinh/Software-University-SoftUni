﻿namespace ByTheCake.ByTheCakeApplication.Controllers
{
    using Infrastructure;
    using WebServer.Server.HTTP.Contracts;

    public class HomeController : Controller
    {
        public IHttpResponse Index() => this.FileViewResponse(@"home\index");

        public IHttpResponse About() => this.FileViewResponse(@"home\about");
    }
}