﻿namespace ByTheCake.ByTheCakeApplication.Models
{
    public class Cake
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}