﻿namespace WebServer.Application.Views
{
    using Server;
    using Server.Contracts;

    internal class UserDetailsView : IView
    {
        private readonly Model model;

        public UserDetailsView(Model model)
        {
            this.model = model;
        }

        public string View()
        {
            return $"<body>Hello, {this.model["name"]}!</body>";
        }
    }
}