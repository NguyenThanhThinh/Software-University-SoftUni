﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.BookLibrary
{
    class Library
    {
        //public string name;
        //public List<Book> books = new List<Book>();

        public string Name { get; set; }
        public List<Book> Books { get; set; }

        public Library()
        {
            this.Books = new List<Book>();
        }


    }
}
